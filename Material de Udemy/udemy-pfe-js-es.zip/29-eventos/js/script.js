
window.addEventListener('load', function() {
    console.log('se ha cargado la pagina');
});