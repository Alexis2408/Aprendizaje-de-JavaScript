
window.addEventListener('load', function() {
    console.log('se ha cargado la pagina');
    
    var searchBtn = document.getElementById('searchBtn');
    searchBtn.addEventListener('click', function() {
        console.log('click');    
    });
    
});